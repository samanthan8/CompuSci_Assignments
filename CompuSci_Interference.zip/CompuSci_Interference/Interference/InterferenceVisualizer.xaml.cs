﻿using GraphControl;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Interference
{
    /// <summary>
    /// Simple visualizer that holds the PictureDisplay
    /// </summary>
    public partial class InterferenceVisualizer : Window
    {
        public PictureDisplay Display;

        /// <param name="rows">The number of rows (subdivisions in y)</param>
        /// <param name="columns">The number of columns (subdivisions in x)</param>
        public InterferenceVisualizer(int rows, int columns)
        {
            InitializeComponent();

            Display = new PictureDisplay(columns, rows);
            MainSpot.Content = Display;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var bitmap = new RenderTargetBitmap((int)ActualWidth, (int)ActualHeight, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(MainSpot);
            Clipboard.SetImage(bitmap);
        }
    }
}
