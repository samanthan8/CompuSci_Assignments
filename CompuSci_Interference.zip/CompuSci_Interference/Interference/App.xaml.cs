﻿using System.Windows;

namespace Interference
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void CallDriver(object sender, StartupEventArgs e)
        {
            InterferenceDriver.Run();
        }
    }
}
