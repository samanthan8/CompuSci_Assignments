﻿using System.ComponentModel;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Transactions;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using DongUtility;


namespace Interference
{
    static internal class InterferenceDriver
    {
        static public void Run()
        {
            //Level1();
            Level2();
            //Level3_1();
            //Level3_2();
            //Challenge();


        }

        static internal void Level1()
        {

            // Initialize Visualizer
            const int rows = 1;
            const int columns = 1000;

            // Constants
            double wavelength = 525e-9; // meters
            double slitDistance = 1.25e-4; // meters
            double distanceToScreen = 10; // meters
            double screenWidth = 1; // meters
            int numSlits = 2;
            double slitThickness = 1e-50;
            int lightSlitDensity = 1;

            InterferenceVisualizer viz = VisualizeSlitExperiment(rows, columns, wavelength, slitDistance, distanceToScreen, screenWidth, 
                screenHeight: screenWidth, numSlits, slitThickness, lightSlitDensity, scaleByDistance: false);

            //See it!!
            viz.Show();
        }

        static internal void Level2()
        {
            // Initialize Visualizer
            const int rows = 1;
            const int columns = 1000;

            // Constants
            double wavelength = 525e-9; // meters
            double slitDistance = 1.25e-4; // meters
            double distanceToScreen = 10; // meters
            double screenWidth = 1; // meters
            int numSlits = 2;
            double slitThickness = 1e-50;
            int lightSlitDensity = 1;

            List<double> wavelengths = new List<double>
            {
                400.0e-9,  // violet light
                450.0e-9,  // blue light
                480.0e-9,  // cyan light
                500.0e-9,  // green light
                525.0e-9,  // green light (specified)
                550.0e-9,  // yellow-green light
                600.0e-9,  // orange light
                650.0e-9,  // red light
                700.0e-9   // deep red light
            };

            List<double> slitDistances = new List<double>
            {
                0.1e-3,    // m
                0.125e-3,  
                0.2e-3,   
                0.25e-3,   
                0.3e-3,    
                0.4e-3,   
                0.5e-3
            };

            List<double> distancesToScreen = new List<double>
            {
                5.0,   // m
                7.0,   
                10.0,  
                12.0,  
                15.0   
            };


            int[] dependentVariables = [0, 1, 1];
            double[][] wavelengthVariedData = FetchVariableData(dependentVariables, [.. wavelengths], screenWidth, numSlits, slitThickness, lightSlitDensity, wavelength, slitDistance, distanceToScreen);

            dependentVariables = [1, 0, 1];
            double[][] slitDistanceVariedData = FetchVariableData(dependentVariables, [.. slitDistances], screenWidth, numSlits, slitThickness, lightSlitDensity, wavelength, slitDistance, distanceToScreen);

            dependentVariables = [1, 1, 0];
            double[][] distancesToScreenVariedData = FetchVariableData(dependentVariables, [.. distancesToScreen], screenWidth, numSlits, slitThickness, lightSlitDensity, wavelength, slitDistance, distanceToScreen);

            String filePath = "C:\\Workspace\\CompuSci\\CompuSci_Interference" + "\\CompuSci_Interference_Data";
            PrintJaggedMatrixToFile(wavelengthVariedData, filePath);
        }

        static internal void Level3_1()
        {
            // Initialize Visualizer
            const int rows = 1;
            const int columns = 1000;

            // Constants
            double wavelength = 525e-9; // meters
            double slitDistance = 1.25e-4; // meters
            double distanceToScreen = 10; // meters
            double screenWidth = 1; // meters
            int numSlits = 3;
            double slitThickness = .01e-50; //meters
            int lightSlitDensity = 1;

            InterferenceVisualizer viz = VisualizeSlitExperiment(rows, columns, wavelength, slitDistance, distanceToScreen, screenWidth, 
                screenHeight:screenWidth, numSlits, slitThickness, lightSlitDensity, scaleByDistance: false);

            //See it!!
            viz.Show();
        }

        static internal void Level3_2()
        {
            // Initialize Visualizer
            const int rows = 1;
            const int columns = 1000;

            // Constants
            double wavelength = 525e-9; // meters
            double slitDistance = 1.25e-4; // meters
            double distanceToScreen = 10; // meters
            double screenWidth = 1; // meters
            int numSlits = 2;
            double slitThickness = .01e-3;
            int lightSlitDensity = 100;

            InterferenceVisualizer viz = VisualizeSlitExperiment(rows, columns, wavelength, slitDistance, distanceToScreen, screenWidth, 
                screenHeight: screenWidth, numSlits, slitThickness, lightSlitDensity, scaleByDistance: false);

            //See it!!
            viz.Show();
        }

        static internal void Challenge()
        {
            // Initialize Visualizer
            const int rows = 250;
            const int columns = 250;

            // Constants
            double wavelength = 525e-9; // meters
            double slitDistance = 1.25e-4; // meters
            double distanceToScreen = 10; // meters
            double screenWidth = 1; // meters
            double screenHeight = 100; // meters
            int numSlits = 2;
            double slitThickness = .01e-3;
            int lightSlitDensity = 10;

            InterferenceVisualizer viz = VisualizeSlitExperiment(rows, columns, wavelength, slitDistance, distanceToScreen, screenWidth, 
                screenHeight, numSlits, slitThickness, lightSlitDensity, scaleByDistance: true);

            //See it!!
            viz.Show();
        }

        private static InterferenceVisualizer VisualizeSlitExperiment(int rows, int columns, double wavelength, double slitDistance, double distanceToScreen, double screenWidth, double screenHeight, int numSlits, double slitThickness, int lightSlitDensity, bool scaleByDistance)
        {
            var viz = new InterferenceVisualizer(rows, columns);

            double[][] intensities = GetScaledIntensity(rows, columns, wavelength, slitDistance, distanceToScreen, screenWidth, 
                screenHeight, numSlits, slitThickness, lightSlitDensity, scaleByDistance);


            // Set the intensity
            for (int ix = 0; ix < columns; ix++)
            {
                for (int iy = 0; iy < rows; iy++)
                {
                    viz.Display.SetCell(ix, iy, wavelength, intensities[ix][iy]);
                }
            }

            return viz;
        }

        static internal double[] GetPathDistances(int numSlits, double distanceBetweenSlits, double slitThickness, int lightSlitDensity, double distanceToScreen, DongUtility.Vector screenPos)
        {
            // Initialize the position of slits

            // Calculate space between the centers of slits
            double totalSpacing = distanceBetweenSlits + slitThickness;

            // Define the range for evenly distributed slits centered around 0
            double start = -((numSlits - 1) / 2.0) * totalSpacing;
            double stop = ((numSlits - 1) / 2.0) * totalSpacing;

            double[] SlitPos = Linspace(start, stop, numSlits);
            int index = 0;

            // Calculate the path distances for each light source
            double[] PathDistances = new double[numSlits * lightSlitDensity];

            foreach (double slit in SlitPos)
            {
                double[] slitLightPos = Linspace(slit - slitThickness / 2, slit + slitThickness / 2, lightSlitDensity);

                foreach (double light in slitLightPos)
                {
                    DongUtility.Vector lightSource = new DongUtility.Vector(light, 0, 0);
                    PathDistances[index] = DongUtility.Vector.Distance(lightSource, screenPos);
                    index++;
                }
            }

            return PathDistances;
        }

        public static double[] Linspace(double start, double stop, int num)
        {
            if (num < 1)
                throw new ArgumentException("num must be at least 1.");

            if (num == 1)
                return new double[] { (start + stop) / 2 };

            double[] result = new double[num];
            double step = (stop - start) / (num - 1);

            for (int i = 0; i < num; i++)
            {
                result[i] = start + step * i;
            }

            return result;
        }

        public static double ComputeInterference(double waveNumber, double[] pathDistances, double time, double angularFrequency, bool scaleByDistance)
        {
            double waveSum = 0; // Initialize waveSum

            // Calculate the sum of the waves at a given time
            foreach (double pathDistance in pathDistances)
            {
                waveSum += scaleByDistance ? Math.Cos(waveNumber * (pathDistance - time * angularFrequency))/pathDistance : Math.Cos(waveNumber * (pathDistance - time * angularFrequency));
            }

            return waveSum;
        }

        public static double GetIntensity(double wavelength, double[] pathDistances, double angularFrequency, double distanceToScreen, bool scaleByDistance)
        {
            // Find the max amplitude of the function over the period
            double maxAmplitude = 0;
            double amplitude = 0;

            // Calculate the wave number
            double waveNumber = 2 * Math.PI / wavelength;

            // Calculate the period of the wave
            double period = 2 * Math.PI / (waveNumber * angularFrequency) + 5;

            // Iterate over the period to find the max amplitude
            for (double time = 0; time <= period; time += 1e-3)
            {
                amplitude = Math.Abs(ComputeInterference(waveNumber, pathDistances, time, angularFrequency, scaleByDistance));
                maxAmplitude = Math.Max(maxAmplitude, amplitude);
            }

            // Compute the raw intensity
            double intensity = Math.Pow(maxAmplitude, 2);

            return intensity;
        }

        public static double[][] GetScaledIntensity(int rows, int columns, double wavelength, double slitDistance, double distanceToScreen, double screenWidth, double screenHeight, int numSlits, double slitThickness, int lightSlitDensity, bool scaleByDistance)
        {
            // Initialize 
            double[][] intensities = new double[columns][];
            double maxIntensity = 0;

            for (int ix = 0; ix < columns; ix++)
            {
                intensities[ix] = new double[rows];

                for (int iy = 0; iy < rows; iy++)
                {
                    double positionX = screenWidth / 2 - screenWidth * ix / columns;
                    double positionY = screenHeight / 2 - screenHeight * iy / rows;
                    DongUtility.Vector screenPos = new DongUtility.Vector(positionX, positionY, distanceToScreen);

                    double[] pathDistances = GetPathDistances(numSlits, slitDistance, slitThickness, lightSlitDensity, distanceToScreen, screenPos);

                    double intensity = GetIntensity(wavelength, pathDistances, angularFrequency: 1e-6, distanceToScreen, scaleByDistance);

                    intensities[ix][iy] = intensity;
                }
            }

            for (int i = 0; i < columns; i++)
            {

                for (int j = 0; j < rows; j++)
                {
                    maxIntensity = Math.Max(maxIntensity, intensities[i][j]);
                }
            }
            double[][] scaledIntensities = intensities
                .Select(row => row.Select(value => value / maxIntensity).ToArray())
                .ToArray();

            return scaledIntensities;
        }

        static public double[][] FetchVariableData(int[] dependentVariables, double[] independentVariableRange, double screenWidth, int numSlits, double slitThickness, int lightSlitDensity, double wavelength, double slitDistance, double distanceToScreen)
        {
            // List to store the X positions of bright spots
            List<double> brightSpotsX = new List<double>();

            double loopStep = 1e-3;

            // Helper function to calculate bright spots
            void CalculateBrightSpots(double currentSlitDistance, double currentWavelength, double currentDistanceToScreen, int numRows)
            {
                // Adjust columns to 1 for a single column of intensities
                double[][] intensities = GetScaledIntensity(rows: numRows, columns: 1, currentWavelength, currentSlitDistance, currentDistanceToScreen, screenWidth, wavelength, numSlits, slitThickness, lightSlitDensity, scaleByDistance: false);

                for (int i = 1; i < intensities.Length - 1; i++) // Start from 1 to avoid out-of-bounds
                {
                    // Check if the current intensity is greater than the surrounding values
                    if (intensities[i][0] > intensities[i - 1][0] && intensities[i][0] > intensities[i + 1][0])
                    {
                        // Calculate the position based on the index
                        double pos = screenWidth / 2 - (double)i / numRows * screenWidth;

                        // Append the position to the list of bright spots
                        brightSpotsX.Add(pos);
                    }
                }
            }

            // Process each dependent variable
            if (dependentVariables[0] == 0) // Wavelength is independent
            {
                foreach (double w in independentVariableRange)
                {
                    CalculateBrightSpots(slitDistance, w, distanceToScreen, numRows: 100);
                }
            }

            if (dependentVariables[1] == 0) // Slit distance is independent
            {
                foreach (double sD in independentVariableRange)
                {
                    CalculateBrightSpots(sD, wavelength, distanceToScreen, numRows: 100);
                }
            }

            if (dependentVariables[2] == 0) // Distance to screen is independent
            {
                foreach (double dS in independentVariableRange)
                {
                    CalculateBrightSpots(slitDistance, wavelength, dS, numRows: 100);
                }
            }

            // Prepare the output array
            int numBrightSpots = brightSpotsX.Count;
            double[][] results = new double[2][];
            results[0] = new double[numBrightSpots]; // For X positions
            if (numBrightSpots != 0)
            {
                results[1] = new double[numBrightSpots - 1]; // For distances between bright spots
            }
            

            // Fill in the X positions
            for (int i = 0; i < numBrightSpots; i++)
            {
                results[0][i] = brightSpotsX[i]; // Store X positions of bright spots
            }

            // Calculate distances between bright spots
            for (int i = 1; i < numBrightSpots; i++)
            {
                results[1][i - 1] = brightSpotsX[i] - brightSpotsX[i - 1]; // Distance between consecutive bright spots
            }

            return results;
        }

        static void PrintJaggedMatrixToFile(double[][] jaggedMatrix, string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                // Iterate over each row in the jagged matrix
                for (int i = 0; i < jaggedMatrix.Length; i++)
                {
                    // Get the current row
                    double[] row = jaggedMatrix[i];

                    // Iterate over each element in the current row
                    for (int j = 0; j < row.Length; j++)
                    {
                        writer.Write(row[j].ToString("F2")); // Format to 2 decimal places
                        if (j < row.Length - 1)
                            writer.Write("\t"); // Use tab separation
                    }
                    writer.WriteLine(); // New line after each row
                }
            }
        }

    }
}
